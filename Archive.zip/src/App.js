import logo from './logo.svg';
import './App.css';
import IVO from './Components/IVO/IVO';

function App() {
  return (
    <IVO></IVO>
  );
}

export default App;
